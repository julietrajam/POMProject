package java.base;

import java.io.IOException;
import java.time.Duration;

//import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcel;


public class ProjectSpecificMethods {
	
	public ChromeDriver driver; 
	
   public String excelFileName;
	
	public static String leadId;
	
	@DataProvider(name = "fetchData",indices=0)
	public String[][] sendData() throws IOException{ 
		
		return ReadExcel.readData(excelFileName);
		
	}
	
	@BeforeMethod
	public void preCondition()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
//		driver.findElement(By.id("username")).sendKeys("demosalesmanager");
//		driver.findElement(By.id("password")).sendKeys("crmsfa");
	}

	@AfterMethod
	public void postCondition() {
		driver.close();

	}
}
