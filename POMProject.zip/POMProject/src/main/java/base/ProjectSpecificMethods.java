package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

//import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.beust.jcommander.Parameter;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcel;


public class ProjectSpecificMethods {
	
	public ChromeDriver driver; 
	
   public String excelFileName;
	
	public static String leadId;
	
	public static Properties prop;
	
	@DataProvider(name = "fetchData",indices=0)
	public String[][] sendData() throws IOException{ 
		
		return ReadExcel.readData(excelFileName);
		
	}
	
	@Parameters({"language"})
	@BeforeMethod
	public void preCondition(String lang) throws IOException
	{
		
		//Step1:Setup the path of the properties file
		FileInputStream fis=new FileInputStream("./src/main/resources/"+lang+".properties");

		//Step2:Create object for properties class
		prop=new Properties();

		//Step3:Load the properties file
		prop.load(fis);
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
//		driver.findElement(By.id("username")).sendKeys("demosalesmanager");
//		driver.findElement(By.id("password")).sendKeys("crmsfa");
	}

	@AfterMethod
	public void postCondition() {
		driver.close();

	}
}
