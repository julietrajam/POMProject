package java.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{
	
	public LoginPage(ChromeDriver driver)
	{
		this.driver=driver;
	}
	
	//@FindBy(how=How.ID,using="username")
	//AND Condition
	@FindBys({
		@FindBy(how=How.CLASS_NAME,using="inputLogin"),
		@FindBy(how=How.XPATH,using="//input[@id='username']")
		
	})
	
    WebElement eleUsername;
	public LoginPage enterUsername() throws InterruptedException
	{
		//System.out.println(driver);
		//driver.findElement(By.name("USERNAME")).sendKeys(uName);
		//Thread.sleep(10000);
		eleUsername.sendKeys("demosalesmanager");
		return this;

	}
	
	//@FindBy(how=How.ID,using="password")
	//OR Condition
	@FindAll({
		@FindBy(how=How.NAME,using="PASSWORD"),
		@FindBy(how=How.XPATH,using="//input[@id='password']")
	})
	WebElement elePassword;
	public LoginPage enterPassword()
	{
		//driver.findElement(By.id("password")).sendKeys(pWord);
		elePassword.sendKeys("crmsfa");
		return this;
	}
	
	@FindBy(how=How.CLASS_NAME,using="decorativeSubmit")
	WebElement eleLogin;
	
	public HomePage clickLoginButton()
	{
		//driver.findElement(By.className("decorativeSubmit")).click();
		eleLogin.click();
		return new HomePage(driver);
	}
}
