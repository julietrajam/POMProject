package java.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;
import pages.ViewLeadPage;

public class CreateLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setFileName()
	{
		excelFileName="CreateLead";
	}

	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String username,String password,String company,String firstName,String lastName) throws InterruptedException
	{
		System.out.println(driver);
		new LoginPage(driver)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmSfaLink()
		.clickLeadsLink()
		.clickCreateLeadsLink()
		.enterCompanyName(company)
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.createLeadButton()
		.verifyFirstName(firstName);
		
	}

	
}
